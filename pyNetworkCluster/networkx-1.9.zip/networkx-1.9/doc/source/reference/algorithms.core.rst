*****
Cores
*****

.. automodule:: networkx.algorithms.core
.. autosummary::
   :toctree: generated/

   core_number
   k_core
   k_shell
   k_crust
   k_corona
